package com.example.quickswitch

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import java.util.Locale

/** All preference keys and their defaults live here. */
object Prefs {
    const val FILE = "prefs_v2"

    const val ENABLED = "enabled"              // master show/hide switch
    const val SIZE = "size"                    // dp, 36..80
    const val ACTIVE_ALPHA = "active_alpha"    // percent, 30..100
    const val IDLE_ALPHA = "idle_alpha"        // percent, 5..60
    const val IDLE_DELAY = "idle_delay"        // seconds, 1..10
    const val STYLE = "style"                  // 0 = iPhone, 1 = circle, 2 = rounded square
    const val COLOR = "color"
    const val DELAY = "delay"                  // ms between the two Recents actions
    const val HAPTIC = "haptic"
    const val HAPTIC_STRENGTH = "haptic_strength" // 0 light, 1 medium, 2 strong
    const val SNAP = "snap"
    const val PEEK = "peek"
    const val LONG_PRESS = "long_press"        // 0 hide 30s, 1 hide until screen on, 2 nothing
    const val ONLY_SELECTED = "only_selected"
    const val ALLOWED = "allowed_packages"
    const val POS_X = "pos_x"                  // 0..1 fraction of screen
    const val POS_Y = "pos_y"

    val COLORS = intArrayOf(
        Color.WHITE,
        0xFF1E88E5.toInt(),
        0xFFE53935.toInt(),
        0xFF43A047.toInt(),
        0xFFFB8C00.toInt(),
        0xFF8E24AA.toInt(),
        0xFFEC407A.toInt(),
        0xFF757575.toInt(),
        Color.BLACK
    )

    fun of(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}

/** Tiny helper: English or Persian text depending on the system language. */
fun tr(en: String, fa: String): String =
    if (Locale.getDefault().language == "fa") fa else en
