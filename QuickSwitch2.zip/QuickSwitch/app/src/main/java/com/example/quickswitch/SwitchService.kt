package com.example.quickswitch

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Accessibility service that draws the floating button.
 * Tap = jump to the previously used app (double Recents action).
 * Uses TYPE_ACCESSIBILITY_OVERLAY, so no "draw over other apps" permission is needed.
 */
class SwitchService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var view: ButtonView? = null
    private var params: WindowManager.LayoutParams? = null
    private var snapAnim: ValueAnimator? = null

    private var lastSwitch = 0L
    private var hiddenByUser = false
    private var hiddenUntilScreenOn = false
    private var foregroundPkg: String? = null
    private var foregroundAllowed = false

    // Touch state
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var longPressed = false

    private val fadeRunnable = Runnable { fadeOut() }
    private val longPressRunnable = Runnable {
        longPressed = true
        performLongPress()
    }
    private val unhideRunnable = Runnable {
        hiddenByUser = false
        updateVisibility()
    }
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (hiddenUntilScreenOn) {
                hiddenUntilScreenOn = false
                hiddenByUser = false
                updateVisibility()
            }
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs.of(this)
        prefs.registerOnSharedPreferenceChangeListener(this)
        registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
        addButton()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        snapAnim?.cancel()
        runCatching { unregisterReceiver(screenReceiver) }
        runCatching { prefs.unregisterOnSharedPreferenceChangeListener(this) }
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Give the system a moment to report the new screen size, then re-clamp.
        handler.postDelayed({ refreshAppearance() }, 300)
    }

    override fun onInterrupt() {}

    // ---------------------------------------------------------------- foreground app tracking

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return
        foregroundPkg = pkg
        recomputeForeground()
        updateVisibility()
    }

    private fun recomputeForeground() {
        val allowed = prefs.getStringSet(Prefs.ALLOWED, emptySet()) ?: emptySet()
        foregroundAllowed = foregroundPkg != null && allowed.contains(foregroundPkg)
    }

    private fun updateVisibility() {
        val only = prefs.getBoolean(Prefs.ONLY_SELECTED, false)
        val show = !hiddenByUser && (!only || foregroundAllowed)
        view?.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ---------------------------------------------------------------- button setup

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sizePx(): Int = dp(prefs.getInt(Prefs.SIZE, 52))
    private fun activeAlpha(): Float = prefs.getInt(Prefs.ACTIVE_ALPHA, 65) / 100f
    private fun idleAlpha(): Float = prefs.getInt(Prefs.IDLE_ALPHA, 20) / 100f

    private fun addButton() {
        if (view != null) return
        val v = ButtonView(this)
        val size = sizePx()
        val p = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        v.setOnTouchListener { _, e -> onTouch(e) }
        view = v
        params = p
        wm.addView(v, p)
        recomputeForeground()
        refreshAppearance()
    }

    /** Re-reads every setting and applies it to the live button. */
    private fun refreshAppearance() {
        val v = view ?: return
        val p = params ?: return
        v.style = prefs.getInt(Prefs.STYLE, 0)
        v.accent = prefs.getInt(Prefs.COLOR, Color.WHITE)
        val size = sizePx()
        p.width = size
        p.height = size
        val t = targetPosition()
        p.x = t[0]
        p.y = t[1]
        v.alpha = activeAlpha()
        runCatching { wm.updateViewLayout(v, p) }
        updateVisibility()
        scheduleFade()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == Prefs.POS_X || key == Prefs.POS_Y) return
        handler.post {
            recomputeForeground()
            refreshAppearance()
        }
    }

    // ---------------------------------------------------------------- position handling

    private fun screen(): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return intArrayOf(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    /** Where the button should sit, based on the saved screen fraction and snap settings. */
    private fun targetPosition(): IntArray {
        val (sw, sh) = screen()
        val size = sizePx()
        val maxX = (sw - size).coerceAtLeast(1)
        val maxY = (sh - size).coerceAtLeast(1)
        val fx = prefs.getFloat(Prefs.POS_X, 1f).coerceIn(0f, 1f)
        val fy = prefs.getFloat(Prefs.POS_Y, 0.4f).coerceIn(0f, 1f)
        var x = (fx * maxX).toInt()
        val y = (fy * maxY).toInt()
        if (prefs.getBoolean(Prefs.SNAP, true)) {
            val peek = if (prefs.getBoolean(Prefs.PEEK, false)) (size * 0.4f).toInt() else 0
            x = if (fx < 0.5f) -peek else maxX + peek
        }
        return intArrayOf(x, y)
    }

    private fun savePosition() {
        val p = params ?: return
        val (sw, sh) = screen()
        val maxX = (sw - p.width).coerceAtLeast(1)
        val maxY = (sh - p.height).coerceAtLeast(1)
        prefs.edit()
            .putFloat(Prefs.POS_X, (p.x.toFloat() / maxX).coerceIn(0f, 1f))
            .putFloat(Prefs.POS_Y, (p.y.toFloat() / maxY).coerceIn(0f, 1f))
            .apply()
    }

    private fun snapToEdge() {
        val p = params ?: return
        val v = view ?: return
        val t = targetPosition()
        p.y = t[1]
        snapAnim?.cancel()
        val anim = ValueAnimator.ofInt(p.x, t[0])
        anim.duration = 200
        anim.addUpdateListener {
            p.x = it.animatedValue as Int
            runCatching { wm.updateViewLayout(v, p) }
        }
        snapAnim = anim
        anim.start()
    }

    // ---------------------------------------------------------------- touch handling

    private fun onTouch(e: MotionEvent): Boolean {
        val p = params ?: return false
        val v = view ?: return false
        val slop = dp(8)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snapAnim?.cancel()
                wake()
                downRawX = e.rawX
                downRawY = e.rawY
                startX = p.x
                startY = p.y
                moved = false
                longPressed = false
                handler.postDelayed(longPressRunnable, 600)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRawX
                val dy = e.rawY - downRawY
                if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                    moved = true
                    handler.removeCallbacks(longPressRunnable)
                }
                if (moved) {
                    val (sw, sh) = screen()
                    p.x = (startX + dx).toInt().coerceIn(0, (sw - p.width).coerceAtLeast(0))
                    p.y = (startY + dy).toInt().coerceIn(0, (sh - p.height).coerceAtLeast(0))
                    runCatching { wm.updateViewLayout(v, p) }
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (moved) {
                    savePosition()
                    snapToEdge()
                } else if (!longPressed) {
                    onTap()
                }
                scheduleFade()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                scheduleFade()
            }
        }
        return true
    }

    // ---------------------------------------------------------------- actions

    private fun onTap() {
        val delay = prefs.getInt(Prefs.DELAY, 150).toLong()
        val now = SystemClock.uptimeMillis()
        if (now - lastSwitch < delay + 250) return   // ignore taps while a switch is running
        lastSwitch = now
        haptic()
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_RECENTS) }, delay)
    }

    private fun performLongPress() {
        when (prefs.getInt(Prefs.LONG_PRESS, 0)) {
            0 -> {
                haptic()
                hiddenByUser = true
                hiddenUntilScreenOn = false
                updateVisibility()
                handler.removeCallbacks(unhideRunnable)
                handler.postDelayed(unhideRunnable, 30_000)
            }
            1 -> {
                haptic()
                hiddenByUser = true
                hiddenUntilScreenOn = true
                updateVisibility()
            }
        }
    }

    private fun haptic() {
        if (!prefs.getBoolean(Prefs.HAPTIC, true)) return
        val ms = when (prefs.getInt(Prefs.HAPTIC_STRENGTH, 1)) {
            0 -> 20L
            2 -> 50L
            else -> 35L
        }
        runCatching {
            @Suppress("DEPRECATION")
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    // ---------------------------------------------------------------- idle fade

    private fun wake() {
        handler.removeCallbacks(fadeRunnable)
        view?.animate()?.cancel()
        view?.alpha = activeAlpha()
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeRunnable)
        handler.postDelayed(fadeRunnable, prefs.getInt(Prefs.IDLE_DELAY, 3) * 1000L)
    }

    private fun fadeOut() {
        view?.animate()?.alpha(idleAlpha())?.setDuration(500)?.start()
    }
}
