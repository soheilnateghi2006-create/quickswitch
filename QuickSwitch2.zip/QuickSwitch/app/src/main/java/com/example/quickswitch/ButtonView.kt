package com.example.quickswitch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** The floating button. Style 0 imitates the iPhone AssistiveTouch button. */
class ButtonView(context: Context) : View(context) {

    var style = 0
        set(value) { field = value; invalidate() }
    var accent = Color.WHITE
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        paint.style = Paint.Style.FILL

        when (style) {
            0 -> {
                // Dark translucent rounded square
                paint.color = Color.argb(235, 40, 40, 44)
                rect.set(0f, 0f, s, s)
                canvas.drawRoundRect(rect, s * 0.28f, s * 0.28f, paint)
                // Three concentric circles, like AssistiveTouch
                paint.color = Color.argb(70, 255, 255, 255)
                canvas.drawCircle(cx, cy, s * 0.36f, paint)
                paint.color = Color.argb(130, 255, 255, 255)
                canvas.drawCircle(cx, cy, s * 0.28f, paint)
                paint.color = accent
                canvas.drawCircle(cx, cy, s * 0.19f, paint)
            }
            1 -> {
                paint.color = accent
                canvas.drawCircle(cx, cy, s / 2f, paint)
                drawSymbol(canvas, cx, cy, s)
            }
            else -> {
                paint.color = accent
                rect.set(0f, 0f, s, s)
                canvas.drawRoundRect(rect, s * 0.26f, s * 0.26f, paint)
                drawSymbol(canvas, cx, cy, s)
            }
        }
    }

    private fun drawSymbol(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        val lum = (0.299 * Color.red(accent) + 0.587 * Color.green(accent) +
            0.114 * Color.blue(accent)) / 255.0
        textPaint.color = if (lum > 0.6) Color.BLACK else Color.WHITE
        textPaint.textSize = s * 0.5f
        val fm = textPaint.fontMetrics
        canvas.drawText("⇄", cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }
}
