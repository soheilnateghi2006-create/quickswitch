plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.quickswitch"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.quickswitch2"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "2.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
